package com.adayo.service.sourcemngservice.Control.SrcMngSystemManage;

/**
 * Created by admin on 2018/4/18.
 */

public interface ISrcMngSystemImp {
    void notifyMsg();
}
