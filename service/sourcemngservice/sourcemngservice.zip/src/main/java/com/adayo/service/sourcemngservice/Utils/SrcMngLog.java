package com.adayo.service.sourcemngservice.Utils;

/**
 * Created by admin on 2018/6/26.
 */

public class SrcMngLog {
    public static String LOG_TAG = "SourceMng_Service_20200819";
    public static String SERVICE_NAME = "SourceMngService";
    public static String PACKAGE_NAME = "com.adayo.service.sourcemngservice";
    public static String ACTION_NAME = "com.adayo.service.sourcemngservice.SourceMngService";
}
