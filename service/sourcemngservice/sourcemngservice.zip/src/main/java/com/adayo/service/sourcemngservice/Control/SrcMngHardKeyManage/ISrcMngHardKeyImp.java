package com.adayo.service.sourcemngservice.Control.SrcMngHardKeyManage;

/**
 * Created by admin on 2018/4/18.
 */

public interface ISrcMngHardKeyImp {
    void notifyMsg(String event);
}
