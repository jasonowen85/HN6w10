package com.adayo.service.sourcemngservice.Control.Interface;

/**
 * Created by admin on 2018/4/11.
 */

public interface ISrcMngSystemSettings {
        void setChannelMute(int muteValue);
        void setSysMute(int muteValue);
}
