package com.adayo.service.sourcemngservice.Control.SrcMngDeviceManage;

/**
 * Created by admin on 2018/4/18.
 */

public interface ISrcMngDeviceImp {
    void notifyMsg();
}
